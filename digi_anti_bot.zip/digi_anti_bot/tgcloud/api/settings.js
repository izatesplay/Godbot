import { db } from 'sdk';
import { eq } from 'sdk/db';
import { groupSettings } from '../schema.js';
import { isAdmin, getOrCreateSettings } from '../lib/utils.js';

export default async function (req) {
  const userId = req.user?.id;
  if (!userId) {
    return Response.json({ error: 'عدم احراز هویت تلگرام' }, { status: 401 });
  }

  const url = new URL(req.url);

  // ۱. دریافت تنظیمات گروه (GET /api/settings?chatId=-100123456)
  if (req.method === 'GET') {
    const chatId = Number(url.searchParams.get('chatId'));
    if (!chatId) {
      return Response.json({ error: 'شناسه گروه (chatId) الزامی است' }, { status: 400 });
    }

    const adminCheck = await isAdmin(chatId, userId);
    if (!adminCheck) {
      return Response.json({ error: 'شما ادمین این گروه نیستید!' }, { status: 403 });
    }

    const settings = await getOrCreateSettings(chatId);
    return Response.json({ settings });
  }

  // ۲. ذخیره تغییرات از مینی‌اپ (POST /api/settings)
  if (req.method === 'POST') {
    const body = await req.json();
    const chatId = Number(body.chatId);
    if (!chatId) {
      return Response.json({ error: 'شناسه گروه نامعتبر است' }, { status: 400 });
    }

    const adminCheck = await isAdmin(chatId, userId);
    if (!adminCheck) {
      return Response.json({ error: 'شما اجازه ویرایش تنظیمات این گروه را ندارید!' }, { status: 403 });
    }

    const allowedUpdates = {
      lockLinks: Boolean(body.lockLinks),
      lockForward: Boolean(body.lockForward),
      lockMedia: Boolean(body.lockMedia),
      lockStickers: Boolean(body.lockStickers),
      lockGifs: Boolean(body.lockGifs),
      lockVoice: Boolean(body.lockVoice),
      cleanService: Boolean(body.cleanService),
      welcomeEnabled: Boolean(body.welcomeEnabled),
      welcomeText: String(body.welcomeText || 'خوش آمدید!'),
      maxWarns: Number(body.maxWarns) || 3,
      antiFlood: Boolean(body.antiFlood),
      floodMaxCount: Number(body.floodMaxCount) || 5,
      floodWindowSec: Number(body.floodWindowSec) || 4,
      nightMode: Boolean(body.nightMode),
      nightStart: Number(body.nightStart) || 0,
      nightEnd: Number(body.nightEnd) || 7,
      badWords: Array.isArray(body.badWords) ? body.badWords : [],
    };

    await db.update(groupSettings).set(allowedUpdates).where(eq(groupSettings.chatId, chatId));
    const updated = await getOrCreateSettings(chatId);

    return Response.json({ ok: true, settings: updated });
  }

  return Response.json({ error: 'Method Not Allowed' }, { status: 405 });
}
