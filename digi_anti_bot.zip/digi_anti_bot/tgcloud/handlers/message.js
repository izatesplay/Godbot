import { api, db } from 'sdk';
import { eq } from 'sdk/db';
import { groupSettings } from '../schema.js';
import {
  isAdmin,
  getOrCreateSettings,
  addWarn,
  resetWarns,
  buildPanelKeyboard,
  isNightTimeNow,
  checkUserFlood,
} from '../lib/utils.js';

export default async function (message) {
  if (!message.chat || !['group', 'supergroup'].includes(message.chat.type)) {
    if (message.text === '/start') {
      await api.sendMessage({
        chat_id: message.chat.id,
        text: '🤖 **به ربات ضدلینک و مدیریت هوشمند گروه (مشابه DIGI ANTI) خوش آمدید!**\n\n۱. من را به گروهتان اضافه و Admin کنید.\n۲. دستور `پنل` یا `/panel` را در گروه بفرستید.\n۳. همچنین می‌توانید از دکمه Mini App کنار کادر پیام، داشبورد گرافیکی را باز کنید.',
        parse_mode: 'Markdown',
      });
    }
    return;
  }

  const chatId = message.chat.id;
  const userId = message.from?.id;
  if (!userId) return;

  const settings = await getOrCreateSettings(chatId);

  // ۱. مدیریت پیام‌های سرویس (ورود و خروج)
  if (message.new_chat_members || message.left_chat_member) {
    if (settings.cleanService) {
      await api.deleteMessage({ chat_id: chatId, message_id: message.message_id }).catch(() => {});
    }
    if (message.new_chat_members && settings.welcomeEnabled) {
      for (const member of message.new_chat_members) {
        if (member.is_bot) continue;
        const welcomeMsg = settings.welcomeText.replace('{name}', member.first_name);
        await api.sendMessage({ chat_id: chatId, text: welcomeMsg });
      }
    }
    return;
  }

  const text = (message.text || message.caption || '').trim();
  const userIsAdmin = await isAdmin(chatId, userId);

  // ۲. دستورات ویژه ادمین‌ها
  if (userIsAdmin) {
    if (text === '/panel' || text === 'پنل' || text === 'تنظیمات') {
      await api.sendMessage({
        chat_id: chatId,
        text: `⚙️ **پنل مدیریت هوشمند گروه**\n🆔 شناسه گروه جهت ورود در مینی‌اپ: \`${chatId}\`\n\nبرای تغییر وضعیت هر قفل روی آن کلیک کنید:`,
        parse_mode: 'Markdown',
        reply_markup: buildPanelKeyboard(settings),
      });
      return;
    }

    // دستور تنظیم ساعت خاموشی: خاموشی 23 7  یا  /night 0 7
    if (text.startsWith('خاموشی ') || text.startsWith('/night ')) {
      const parts = text.replace(/^(\/night|خاموشی)\s+/i, '').trim().split(/\s+/);
      const startHour = parseInt(parts[0], 10);
      const endHour = parseInt(parts[1], 10);

      if (
        !isNaN(startHour) &&
        !isNaN(endHour) &&
        startHour >= 0 &&
        startHour <= 23 &&
        endHour >= 0 &&
        endHour <= 23
      ) {
        await db
          .update(groupSettings)
          .set({ nightMode: true, nightStart: startHour, nightEnd: endHour })
          .where(eq(groupSettings.chatId, chatId));

        await api.sendMessage({
          chat_id: chatId,
          text: `🌙 ساعت خاموشی خودکار گروه فعال شد!\n⏰ بازه خاموشی: از ساعت **${startHour}:00** تا **${endHour}:00** به وقت ایران.`,
          parse_mode: 'Markdown',
        });
      } else {
        await api.sendMessage({
          chat_id: chatId,
          text: '⚠️ فرمت دستور اشتباه است! مثال صحیح:\n`خاموشی 0 7` یا `/night 23 7`',
          parse_mode: 'Markdown',
        });
      }
      return;
    }

    // افزودن کلمه به فیلتر
    if (text.startsWith('فیلتر ') || text.startsWith('/filter ')) {
      const word = text.replace(/^(\/filter|فیلتر)\s+/i, '').trim();
      if (word && !settings.badWords.includes(word)) {
        const updatedWords = [...settings.badWords, word];
        await db.update(groupSettings).set({ badWords: updatedWords }).where(eq(groupSettings.chatId, chatId));
        await api.sendMessage({ chat_id: chatId, text: `🚫 کلمه «${word}» فیلتر شد.` });
      }
      return;
    }

    // حذف کلمه از فیلتر
    if (text.startsWith('حذف فیلتر ') || text.startsWith('/unfilter ')) {
      const word = text.replace(/^(\/unfilter|حذف فیلتر)\s+/i, '').trim();
      const updatedWords = settings.badWords.filter((w) => w !== word);
      await db.update(groupSettings).set({ badWords: updatedWords }).where(eq(groupSettings.chatId, chatId));
      await api.sendMessage({ chat_id: chatId, text: `✅ کلمه «${word}» آزاد شد.` });
      return;
    }

    // دستورات ریپلایی
    if (message.reply_to_message) {
      const targetUser = message.reply_to_message.from;
      const targetId = targetUser.id;

      if (text === 'بن' || text === '/ban') {
        await api.banChatMember({ chat_id: chatId, user_id: targetId });
        await api.sendMessage({ chat_id: chatId, text: `🔨 کاربر ${targetUser.first_name} اخراج شد.` });
        return;
      }

      if (text === 'سکوت' || text === '/mute') {
        await api.restrictChatMember({
          chat_id: chatId,
          user_id: targetId,
          permissions: { can_send_messages: false },
        });
        await api.sendMessage({ chat_id: chatId, text: `🔇 کاربر ${targetUser.first_name} بی‌صدا شد.` });
        return;
      }

      if (text === 'حذف سکوت' || text === '/unmute') {
        await api.restrictChatMember({
          chat_id: chatId,
          user_id: targetId,
          permissions: {
            can_send_messages: true,
            can_send_other_messages: true,
            can_add_web_page_previews: true,
          },
        });
        await api.sendMessage({ chat_id: chatId, text: `🔊 سکوت ${targetUser.first_name} برداشته شد.` });
        return;
      }

      if (text === 'اخطار' || text === '/warn') {
        const warns = await addWarn(chatId, targetId);
        if (warns >= settings.maxWarns) {
          await api.banChatMember({ chat_id: chatId, user_id: targetId });
          await resetWarns(chatId, targetId);
          await api.sendMessage({
            chat_id: chatId,
            text: `🚫 کاربر ${targetUser.first_name} با دریافت ${warns} اخطار از گروه اخراج شد!`,
          });
        } else {
          await api.sendMessage({
            chat_id: chatId,
            text: `⚠️ اخطار برای ${targetUser.first_name} ثبت شد (${warns}/${settings.maxWarns}).`,
          });
        }
        return;
      }

      if (text === 'حذف اخطار' || text === '/unwarn') {
        await resetWarns(chatId, targetId);
        await api.sendMessage({ chat_id: chatId, text: `✅ اخطارهای ${targetUser.first_name} صفر شد.` });
        return;
      }
    }

    return; // ادمین‌ها محدود نمی‌شوند
  }

  // ۳. بررسی ساعت خاموشی گروه (Night Mode) برای کاربران عادی
  if (isNightTimeNow(settings)) {
    await api.deleteMessage({ chat_id: chatId, message_id: message.message_id }).catch(() => {});
    return;
  }

  // ۴. بررسی سیستم ضد اسپم (Anti-Flood)
  if (settings.antiFlood) {
    const isFlooding = await checkUserFlood(
      chatId,
      userId,
      settings.floodMaxCount,
      settings.floodWindowSec
    );

    if (isFlooding) {
      await api.deleteMessage({ chat_id: chatId, message_id: message.message_id }).catch(() => {});
      const oneHourLater = Math.floor(Date.now() / 1000) + 3600;
      await api
        .restrictChatMember({
          chat_id: chatId,
          user_id: userId,
          until_date: oneHourLater,
          permissions: { can_send_messages: false },
        })
        .catch(() => {});

      await api.sendMessage({
        chat_id: chatId,
        text: `🌊 کاربر **${message.from.first_name}** به دلیل ارسال پیام رگباری (Spam) به مدت **۱ ساعت** بی‌صدا شد!`,
        parse_mode: 'Markdown',
      });
      return;
    }
  }

  // ۵. بررسی قفل‌ها برای کاربران عادی
  let violationReason = null;

  if (settings.lockLinks) {
    const entities = message.entities || message.caption_entities || [];
    const hasEntityLink = entities.some((e) => ['url', 'text_link', 'mention'].includes(e.type));
    const linkRegex = /(https?:\/\/[^\s]+)|(t\.me\/[^\s]+)|(@[a-zA-Z0-9_]{4,})/i;
    if (hasEntityLink || linkRegex.test(text)) {
      violationReason = 'ارسال لینک یا آیدی';
    }
  }

  if (!violationReason && settings.lockForward && (message.forward_origin || message.forward_from || message.forward_from_chat)) {
    violationReason = 'فوروارد پیام';
  }

  if (!violationReason && settings.lockStickers && message.sticker) violationReason = 'ارسال استیکر';
  if (!violationReason && settings.lockGifs && message.animation) violationReason = 'ارسال گیف';
  if (!violationReason && settings.lockVoice && (message.voice || message.video_note)) violationReason = 'ارسال ویس';
  if (!violationReason && settings.lockMedia && (message.photo || message.video || message.document)) {
    violationReason = 'ارسال رسانه';
  }

  if (!violationReason && settings.badWords.length > 0 && text) {
    const foundBadWord = settings.badWords.some((word) => text.toLowerCase().includes(word.toLowerCase()));
    if (foundBadWord) violationReason = 'کلمات غیرمجاز';
  }

  if (violationReason) {
    await api.deleteMessage({ chat_id: chatId, message_id: message.message_id }).catch(() => {});
  }
}
