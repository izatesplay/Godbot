import { api, db } from 'sdk';
import { eq } from 'sdk/db';
import { groupSettings } from '../schema.js';
import { isAdmin, getOrCreateSettings, buildPanelKeyboard } from '../lib/utils.js';

export default async function (query) {
  const chatId = query.message?.chat?.id;
  const userId = query.from.id;
  const data = query.data;

  if (!chatId) return;

  const userIsAdmin = await isAdmin(chatId, userId);
  if (!userIsAdmin) {
    await api.answerCallbackQuery({
      callback_query_id: query.id,
      text: '⛔️ فقط ادمین‌های گروه اجازه تغییر تنظیمات را دارند!',
      show_alert: true,
    });
    return;
  }

  if (data === 'close_panel') {
    await api.deleteMessage({ chat_id: chatId, message_id: query.message.message_id }).catch(() => {});
    return;
  }

  if (data === 'show_chat_id') {
    await api.answerCallbackQuery({
      callback_query_id: query.id,
      text: `شناسه گروه شما: ${chatId}\nاین کد را در داشبورد مینی‌اپ وارد کنید.`,
      show_alert: true,
    });
    return;
  }

  if (data.startsWith('toggle:')) {
    const field = data.split(':')[1];
    const currentSettings = await getOrCreateSettings(chatId);

    if (field in currentSettings) {
      const newValue = !currentSettings[field];
      await db
        .update(groupSettings)
        .set({ [field]: newValue })
        .where(eq(groupSettings.chatId, chatId));

      const updatedSettings = { ...currentSettings, [field]: newValue };

      await api.editMessageReplyMarkup({
        chat_id: chatId,
        message_id: query.message.message_id,
        reply_markup: buildPanelKeyboard(updatedSettings),
      });

      await api.answerCallbackQuery({
        callback_query_id: query.id,
        text: '✅ تغییر اعمال شد.',
      });
    }
  }
}
