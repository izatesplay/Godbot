import { table, integer, text, boolean, json, index } from 'sdk/db';

// جدول تنظیمات اختصاصی هر گروه (نسخه پیشرفته)
export const groupSettings = table('group_settings', {
  chatId: integer('chat_id').primaryKey(),
  lockLinks: boolean('lock_links').notNull().default(true),
  lockForward: boolean('lock_forward').notNull().default(false),
  lockMedia: boolean('lock_media').notNull().default(false),
  lockStickers: boolean('lock_stickers').notNull().default(false),
  lockGifs: boolean('lock_gifs').notNull().default(false),
  lockVoice: boolean('lock_voice').notNull().default(false),
  cleanService: boolean('clean_service').notNull().default(true),
  welcomeEnabled: boolean('welcome_enabled').notNull().default(true),
  welcomeText: text('welcome_text').notNull().default('سلام {name} عزیز، به گروه خوش آمدی! 🌹'),
  maxWarns: integer('max_warns').notNull().default(3),
  badWords: json('bad_words').notNull().default([]),

  // قابلیت‌های جدید: ضد اسپم (Anti-Flood)
  antiFlood: boolean('anti_flood').notNull().default(true),
  floodMaxCount: integer('flood_max_count').notNull().default(5), // حداکثر ۵ پیام
  floodWindowSec: integer('flood_window_sec').notNull().default(4), // در ۴ ثانیه

  // قابلیت‌های جدید: ساعت خاموشی (Night Mode - به وقت ایران)
  nightMode: boolean('night_mode').notNull().default(false),
  nightStart: integer('night_start').notNull().default(0), // ساعت شروع (مثلا 0 بامداد)
  nightEnd: integer('night_end').notNull().default(7),     // ساعت پایان (مثلا 7 صبح)
});

// جدول ذخیره تعداد اخطارهای کاربران
export const userWarns = table('user_warns', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  chatId: integer('chat_id').notNull(),
  userId: integer('user_id').notNull(),
  count: integer('count').notNull().default(0),
}, (t) => ({
  chatUserIdx: index('chat_user_idx').on(t.chatId, t.userId),
}));

// جدول ردیابی پیام‌های رگباری (Anti-Flood Tracker)
export const floodTracker = table('flood_tracker', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  chatId: integer('chat_id').notNull(),
  userId: integer('user_id').notNull(),
  msgCount: integer('msg_count').notNull().default(1),
  windowStart: integer('window_start').notNull(), // Timestamp برحسب ثانیه
}, (t) => ({
  floodIdx: index('flood_idx').on(t.chatId, t.userId),
}));
